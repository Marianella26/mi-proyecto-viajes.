# Proyecto: Explora el Mundo 🌍

Este es mi primer proyecto web del diplomado en fundamentos de programación. Se trata de una aplicación de viajes que incluye una galería, filtro de imágenes, vista de detalle y formulario de contacto.

## Tecnologías usadas

- HTML semántico
- CSS personalizado
- Bootstrap 5
- JavaScript
- Git y GitHub

## Funcionalidades

- Filtro de imágenes por categoría
- Vista ampliada del destino
- Validación de formulario de contacto
- Diseño responsivo

## Autora

Marianella – 2025

## Demo

🔗 [Ver en GitHub Pages](https://tuusuario.github.io/mi-proyecto-viajes/)
