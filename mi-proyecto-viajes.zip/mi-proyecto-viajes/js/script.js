document.addEventListener('DOMContentLoaded', () => {
  const botones = document.querySelectorAll('.filter-btn');
  const tarjetas = document.querySelectorAll('[data-category]');

  botones.forEach(boton => {
    boton.addEventListener('click', () => {
      const categoria = boton.getAttribute('data-category');
      tarjetas.forEach(tarjeta => {
        const cat = tarjeta.getAttribute('data-category');
        tarjeta.style.display = (categoria === 'todos' || categoria === cat) ? 'block' : 'none';
      });
    });
  });

  const formulario = document.getElementById('formulario-contacto');
  if (formulario) {
    formulario.addEventListener('submit', function (event) {
      event.preventDefault();
      const nombre = document.getElementById('nombre').value.trim();
      const email = document.getElementById('email').value.trim();
      const mensaje = document.getElementById('mensaje').value.trim();
      if (nombre === '' || email === '' || mensaje === '') {
        alert('Por favor, completa todos los campos.');
      } else {
        alert('Formulario enviado correctamente. ¡Gracias por tu mensaje!');
        formulario.reset();
      }
    });
  }
});
